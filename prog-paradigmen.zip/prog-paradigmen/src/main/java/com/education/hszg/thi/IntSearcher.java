package com.education.hszg.thi;

public interface IntSearcher {
    boolean find (int elementToFind, int[] numbers);
}
