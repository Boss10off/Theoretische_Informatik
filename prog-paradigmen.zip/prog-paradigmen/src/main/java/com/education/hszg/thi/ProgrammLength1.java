package com.education.hszg.thi;

public class ProgrammLength1 {
    boolean isMember(int i) {
        if (i == 5)
            return true;
        return false;
    }
}
