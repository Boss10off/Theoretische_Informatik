package com.education.hszg.thi;

public class ProgrammLength2 {

    boolean isMember(int i) {
        if (i == 6)
            return true;
        return false;
    }
}
