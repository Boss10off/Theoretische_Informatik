package com.education.hszg.thi.search;

public interface IntSearcher {
    boolean find (int elementToFind, int[] numbers);
}
