package com.education.hszg.thi.sort;

public interface IntSorter {
    public int[] sort(int[] numbers);

}
